



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de connexion</title>
    <link rel="stylesheet" href="../Css/styleForm.css">
    <script defer src="../Js/indexform.js"></script>
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;

}

body {
    background-color: #23a1f0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;


}

form {
    display: flex;
    flex-direction: column;
    background-color: #fff;
    padding: 10px;
    border-radius: 6px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
   
    
}

h4 {
    text-align: center;
    font-size: 20px;
}

hr {
    margin: 10px 0;
    background-color: #fff;
    border: 0;
    height: 1px;
    width: 100%;
}

label {
    margin-bottom: 8px;
}

input {
    margin-bottom: 6px;
    padding: 5px;
    outline: 0;
    border: 1px solid rgba(0, 0, 0, 0.4);
}

input:focus {
    border: 1px solid #23a1f0;
}

input[type='submit'] {
    color: white;
    background-color: #23a1f0;
    margin-top: 15px;
    border: 1px solid #23a1f0;
    cursor: pointer;
}

p {

    font-size: 15px;
    color: #666;
    line-height: 2.2;
    margin-top: 20px;
}

p a {

    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
    </style>
</head>
<body>

    <form method="POST" action="<?php echo e(route('login')); ?>"> 
        <?php echo csrf_field(); ?>

        <h4>Se Connecter</h4>
        <hr>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" required>

        <label for="password">Mot de passe</label>
        <input type="password" name="password" id="password" required>

       
        <input type="submit" value="Valider">
        
    </form>
    
</body>
</html><?php /**PATH /Users/falilou/Desktop/me/dossier-projet/projet-web/laravel/Application-web-1/resources/views/dashboard.blade.php ENDPATH**/ ?>