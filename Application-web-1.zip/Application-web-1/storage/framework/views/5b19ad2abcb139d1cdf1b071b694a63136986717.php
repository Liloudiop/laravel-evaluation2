<link rel="stylesheet" href="<?php echo e(asset('css/create.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('Js/form.css')); ?>">


    <form action="/store2" method="post">
        <?php echo csrf_field(); ?>
    <h4>Inscrivez vous</h4>
        <hr>

        <label for="prenom">Prenom</label>
        <input type="text" name="prenom" id="prenom" required> 


        <label for="email">Email</label>
        <input type="text" name="email" id="email" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>
       
        <input type="submit" value="Valider">

        
        <p class="p">Merci de remplir tous les champs  pour ajouter <br><span>un utilisateur.</span> </p>
    </form>
<?php /**PATH /Users/falilou/Desktop/me/dossier-projet/projet-web/laravel/Application-web-1/resources/views/inscrire.blade.php ENDPATH**/ ?>