
<link rel="stylesheet" href="<?php echo e(asset('css/create.css')); ?>">

      <form action="/edit/traitement" method="post">
         <h4>Modifier utilisateur</h4>

        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($user->id); ?>" id="id" />
        <label>Prenom</label>
        <input type="text" name="prenom" id="prenom" value="<?php echo e($user->name); ?>" >
        <label>Email</label>
        <input type="text" name="email" id="email" value="<?php echo e($user->email); ?>" >
        
        <input type="submit" value="Valider" >
        <p class="p">Merci d'apporter des modifications pour cette <br><span>utilisateur.</span> </p>

    </form>
    

<?php /**PATH /Users/falilou/Desktop/me/dossier-projet/projet-web/laravel/Application-web-1/resources/views/edit.blade.php ENDPATH**/ ?>