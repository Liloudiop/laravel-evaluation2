

<link rel="stylesheet" href="<?php echo e(asset('css/liste.css')); ?>">
<div class="container">

    <h2>Voici la liste des utilisateurs</h2>
    <li><a href="create">Ajouter un utilisateur</a></li>
</div>

<table  style="width: 100%">
    <thead>
        <th>Prenom</th>
        <th>Email</th>
        
        <th colspan="2">Action</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            
            <td><a href="/edit/<?php echo e(($user->id)); ?>"><button class="modifier">Modifier</button></a></td>


            <form action="<?php echo e(route ('delete', $user['id'])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <td><button class="supprimer">Supprimer</button></td>
            </form>
            

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </tbody>
</table>




<?php /**PATH /Users/falilou/Desktop/me/dossier-projet/projet-web/laravel/Application-web-1/resources/views//liste.blade.php ENDPATH**/ ?>