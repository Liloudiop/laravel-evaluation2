<link rel="stylesheet" href="{{asset('css/create.css')}}">
<link rel="stylesheet" href="{{asset('Js/form.css')}}">


    <form action="/store2" method="post">
        @csrf
    <h4>Inscrivez vous</h4>
        <hr>

        <label for="prenom">Prenom</label>
        <input type="text" name="prenom" id="prenom" required> 


        <label for="email">Email</label>
        <input type="text" name="email" id="email" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>
       
        <input type="submit" value="Valider">

        {{-- <p class="p">Vous avez deja un compte ? <a href="/pages/login">se connecter</a></p> --}}
        <p class="p">Merci de remplir tous les champs  pour ajouter <br><span>un utilisateur.</span> </p>
    </form>
