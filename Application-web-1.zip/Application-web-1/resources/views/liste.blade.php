
<title>Restaurant</title>
<link rel="stylesheet" href="{{asset('css/liste.css')}}">
<div class="container">

    <h2>Voici la liste des utilisateurs qui ont crées un compte !</h2>
    <ul>

        <li ><a href="/" class="lien_site">Retourner sur le site</a></li>
        <li><a href="/create">Ajouter un utilisateur</a></li>
    </ul>
</div>

<table  style="width: 100%">
    <thead>
        <th>Prenom</th>
        <th>Email</th>
        {{-- <th>Telephone</th> --}}
        <th colspan="2">Action</th>
    </thead>
    <tbody>
        @foreach ($user as $user)
        <tr>
            <td>{{ $user->name }}</td>
            <td>{{ $user->email }}</td>
            {{-- <td>{{ $user->telephone }}</td> --}}
            <td><a href="/edit/{{{($user->id)}}}"><button class="modifier">Modifier</button></a></td>


            <form action="{{ route ('delete', $user['id']) }}" method="post">
                @csrf
                @method('DELETE')
                <td><button class="supprimer">Supprimer</button></td>
            </form>
            

            @endforeach
        </tr>
    </tbody>
</table>




