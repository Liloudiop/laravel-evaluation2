
<link rel="stylesheet" href="{{asset('css/create.css')}}">

      <form action="/edit/traitement" method="post">
         <h4>Modifier utilisateur</h4>

        {!! csrf_field() !!}
        @method("PATCH")
        <input type="hidden" name="id" id="id" value="{{$user->id}}" id="id" />
        <label>Prenom</label>
        <input type="text" name="prenom" id="prenom" value="{{$user->name}}" >
        <label>Email</label>
        <input type="text" name="email" id="email" value="{{$user->email}}" >
        {{-- <label>Telephone</label>
        <input type="text" name="telephone" id="telephone" value="{{$user->telephone}}" > --}}
        <input type="submit" value="Valider" >
        <p class="p">Merci d'apporter des modifications pour cette <br><span>utilisateur.</span> </p>

    </form>
    

