<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;


class UserController extends Controller
{
    public function liste() {

        $user = User::all();

        //  dd($formateur);
        return view('liste', ['user' => $user]);

    }

    public function delete($id) {
        $user = User::find($id);

        if ($user) {
            $user->delete();
        }
        return redirect("/liste");

    }


    public function edit($id)
    {
        $user = User::find($id);
        return view('edit',['user' => $user]);
    }

    

    public function editTraitement(Request $request) {


        $user = User::find($request->id);

            
            $user->name = $request->input('prenom');
            $user->email = $request->input('email');
            
            $user ->update();
            return redirect("/liste");
        }


        public function create() {
            return view('create');
    
        }
    
        public function inscrire() {
            return view('inscrire');
    
        }
    
    
    
         // Function pour enregistrer dans la base de donnee
    
        public function store1(Request $request){
            // return "Formulaire Soumis" ;
            // dd($request['prix']);
            if ($request) {
                # code...
                $user = new User();
                
                $user->name = $request->input('prenom');
                $user->email = $request->input('email');
                $user->password = $request->input('password');
                
                $user ->save();
                return redirect("/liste");
            }
        }

        public function store2(Request $request){
            // return "Formulaire Soumis" ;
            // dd($request['prix']);
            if ($request) {
                # code...
                $user = new User();
                
                $user->name = $request->input('prenom');
                $user->email = $request->input('email');
                $user->password = $request->input('password');
                
                $user ->save();
                return redirect("/index");
            }
        }
}
