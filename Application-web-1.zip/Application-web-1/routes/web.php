<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/dashboard', function () {
    return view('dashboard');
}); //->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';




    // Route::get('form', [App\Http\Controllers\Pages::class, "form"]);

    Route::get('categories', function() {
        return view("categories");
    });
   
    Route::get('category', function() {
        return view("category");
    });

    Route::get('foods', function() {
        return view("foods");
    });

    Route::get('food-search', function() {
        return view("food-search");
    });

    Route::get('/index', function() {
        return view("index");
    });

    Route::get('order', function() {
        return view("order");
    });

    Route::get('login', function() {
        return view("auth/login");
    });

    Route::get('register', function() {
        return view("auth/register");
    });

    Route::get('/liste', "App\Http\Controllers\UserController@liste");
    Route::delete('/delete/{id}', "App\Http\Controllers\UserController@delete")->name('delete');
    Route::get('/edit/{id}', "App\Http\Controllers\UserController@edit")->name('edit');
    Route::patch('/edit/traitement', "App\Http\Controllers\UserController@editTraitement")->name('editTraitement');
    Route::get('/create', "App\Http\Controllers\UserController@create")->name('create');
    Route::get('/create', "App\Http\Controllers\UserController@inscrire")->name('inscrire');
    Route::post('/store1', "App\Http\Controllers\UserController@store1")->name('store1');
    Route::post('/store2', "App\Http\Controllers\UserController@store2")->name('store2');
    Route::post('/login', "App\Http\Controllers\Auth\AuthenticatedSessionController@create")->name('login');
    Route::post('/store', "App\Http\Controllers\Auth\AuthenticatedSessionController@store")->name('store');